// creat. r. u. d
// Array para armazenar as tarefas
let tasks = [];

// Função para adicionar uma nova tarefa
function addTask() {
    const taskInput = document.getElementById('taskInput');
    const taskList = document.getElementById('taskList');

    const taskText = taskInput.value.trim();

    if (taskText !== '') {
        tasks.push(taskText);

        // Limpa o campo de entrada
        taskInput.value = '';

        // Atualiza a lista de tarefas
        updateTaskList(taskList);
    }
}

// Função para atualizar a lista de tarefas
function updateTaskList(taskList) {
    // Limpa a lista antes de atualizar
    taskList.innerHTML = '';

    // Adiciona cada tarefa à lista
    tasks.forEach(task => {
        const li = document.createElement('li');
        li.textContent = task;

        // Adiciona um botão para remover a tarefa
        const removeButton = document.createElement('button');
        removeButton.textContent = 'Remove';
        removeButton.onclick = function () {
            removeTask(task);
        };

        li.appendChild(removeButton);
        taskList.appendChild(li);
    });
}

// Função para remover uma tarefa
function removeTask(taskText) {
    // Filtra as tarefas, removendo a tarefa específica
    tasks = tasks.filter(task => task !== taskText);

    // Obtém a lista de tarefas
    const taskList = document.getElementById('taskList');

    // Atualiza a lista de tarefas
    updateTaskList(taskList);
}
